bs4 package
===========
          
Module contents
---------------

.. automodule:: bs4
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 1

   bs4.builder

Submodules
----------

bs4.css module
--------------

.. automodule:: bs4.css
   :members:
   :undoc-members:
   :show-inheritance:

bs4.dammit module
-----------------

.. automodule:: bs4.dammit
   :members:
   :undoc-members:
   :show-inheritance:

bs4.element module
------------------

.. automodule:: bs4.element
   :members:
   :undoc-members:
   :show-inheritance:

bs4.filter module
-----------------
.. automodule:: bs4.filter
   :members:
   :undoc-members:
   :show-inheritance:

bs4.formatter module
--------------------

.. automodule:: bs4.formatter
   :members:
   :undoc-members:
   :show-inheritance:

bs4._typing module
------------------

.. automodule:: bs4._typing
   :members:
   :undoc-members:
   :private-members:
   :show-inheritance:

bs4.diagnose module
-------------------

.. automodule:: bs4.diagnose
   :members:
   :undoc-members:
   :show-inheritance:
